
import React from 'react';
import './App.css';

function EventsFuncCom() {

 // event handler 
    function click_Me()
    {
        alert('ok')
    }

  return (
    <div className='emp'>
          <button onClick={click_Me}> Click me </button>

          {/* <button onClick={()=>alert('clicked')}> Click me </button> */}

      </div>
  );
}

export default EventsFuncCom;
