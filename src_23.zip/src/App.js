
import './App.css';
import React from 'react';
// import Header from './Header';
// import Footer from './Footer';
// import Image from './Image';
// import Content from './Content';
// import Emp from './Emp';
// import Employee from './Employee';
// import Student from '.Student';

// import Sunadh_card from './Sunadh_card';

// import StateEX from './StateEX';
// import CounterEx from './CounterEx';
// import EmpStateEx from './EmpStateEx';
// import EventsFuncCom from './EventsFuncCom';

// import EventClasEx from './EventClasEx';

// import Conditions from './Conditions';

// import Sample from './Sample';
// import List from './List';

// import Table from './Table.js'
import FormEx from './FormEx';

function App() {

  return (
    <div className="App">

      <FormEx />
      

      {/* <Table /> */}

      {/* <List name='Apple' price='2000' color='red' />
      <List name='Bannana' price='1000' color='yellow'/>
      <List name='Orange' price='500' color='orange color'/> */}


      {/* <Sample/> */}
     
     {/* <Conditions/>   */}
      {/* <EventClasEx/>  */}

      {/* <EventsFuncCom />  */}

      {
      /* <StateEX />
      <CounterEx />
      <EmpStateEx />  */
      }



      {/* <Sunadh_card/> */}

      {/* <Student/> */}

      {/* <table>
        <tr>
          <td>       <Employee className='emp' emp_logo='https://i.pinimg.com/736x/50/9a/61/509a613c0d267d9a3b8c3a5233068150.jpg' emp_id='1001' emp_name='sreenivas' emp_sal='55000' />
 </td>
          <td>        <Employee className='emp' emp_logo='https://i.pinimg.com/736x/50/9a/61/509a613c0d267d9a3b8c3a5233068150.jpg' emp_id='1001' emp_name='sreenivas' emp_sal='55000' />
</td>
          <td>       <Employee className='emp' emp_logo='https://i.pinimg.com/736x/50/9a/61/509a613c0d267d9a3b8c3a5233068150.jpg' emp_id='1001' emp_name='sreenivas' emp_sal='55000' />
 </td>
          <td>        <Employee className='emp' emp_logo='https://i.pinimg.com/736x/50/9a/61/509a613c0d267d9a3b8c3a5233068150.jpg' emp_id='1001' emp_name='sreenivas' emp_sal='55000' />
</td>
           <td>       <Employee className='emp' emp_logo='https://i.pinimg.com/736x/50/9a/61/509a613c0d267d9a3b8c3a5233068150.jpg' emp_id='1001' emp_name='sreenivas' emp_sal='55000' />
 </td>
        </tr>
      </table>
      
<p className='text-danger'>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
</p> */}
      
  
    </div>
  );
}

export default App;
