import React from 'react'

function FormEx() {

    return (
        <div>
            <form>
                
             
                <fieldset>
                    <legend>
                        name Details
                    </legend>
        <input type="text" name="name" placeholder='enter ur fname' required />
        <input type="text" name="name" placeholder='enter ur lname' required />
                    </fieldset>
                <input type="submit" value="Submit" />
            </form>
                  
        </div>
    )
}

export default FormEx