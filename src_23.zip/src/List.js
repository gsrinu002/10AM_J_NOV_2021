import React from 'react'

export default function List(props) {

  return (
      <div>
             <ul>
              <li>{props.name}</li>
              <li>{props.price} </li>
              <li>{props.color} </li>
          </ul>
          <hr/>
      </div>
  )
}
