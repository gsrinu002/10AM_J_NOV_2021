import React from 'react';
import './App.css';

// class  component 
class EventClassEx extends React.Component {

    constructor() {
        super()

        this.state = {
         name : 'Check Click'
        }
    }
    click_Event()
    {
        alert('ok')
        // this.setState({
        //     name:this.state.name
        // })
    }
    render() {
        return (
            <div className='emp'>
                <button onClick={this.click_Event}>{this.state.name}</button>
            </div>
        );
    };
}
export default EventClassEx;
