import React from 'react';
import './App.css';

// class  component 
class EmpStateEx extends React.Component {

    constructor() {
        super()

        this.state = {
            name: "sreenivas",
            age: 22,
            qual: "MCA",
            heading:'mouse over on me'
        }

    }
//  method
    changeEmpDetails() {
        this.setState({
            name: "sreenivas _ G",
            age: 32,
            qual: "MCA 2009",
            heading:'mouse out on me'
        })
        
    }
    getBackEmpDetails() {

        this.setState({
            name: "sreenivas",
            age: 22,
            qual: "MCA",
            heading:'mouse over on me'
        })   
    }
    render() {
        return (
            <div className='emp'>
                <h2>Emp Name : {this.state.name}</h2>
                <h2>Emp Age : {this.state.age}</h2>
                <h2>Emp Qual : {this.state.qual}</h2>
                <button
                    onMouseOver={() => this.changeEmpDetails()}
                    onMouseOut={() => this.getBackEmpDetails()}>
                    
                    {this.state.heading}
                </button>

            </div>
        );
    };

}
export default EmpStateEx;
