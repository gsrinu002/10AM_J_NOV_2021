import React from 'react';
import './App.css';

// class  component 
class Conditions extends React.Component {
    constructor() {
        super()
       this.state={
	     isLoggedIn :true 
        }

    }
    render() {

    // if(this.state.isLoggedIn)
	// {
	// return <div> welcome sreenivas</div>
	// }
	// else 
	// {
	// return <div> welcome guest</div>
	// }
        
// let message  
//         if (this.state.isLoggedIn)
// {
// 	message=<div> welcome sreenivas</div>
// }
// else
// {
// 	message=<div> welcome guest</div>
//  }
//         return (
//             <div> {message} </div>
//         )
      
//  if cond ?  state : state
        
// return (
//    this.state.isLoggedIn ? 
//    <div> welcome sreenivas</div> : 
//    <div> welcome guest</div>
// )
        

	return( this.state.isLoggedIn && <div> welcome sreenivas</div> )


    };

}
export default Conditions;
