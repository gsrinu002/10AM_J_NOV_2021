import React from 'react'
import Columns from './Columns'
import './App.css';

function Table() {
    return (
        <table>
            <tbody>
                <tr>
                    <Columns name='sreenivas' />
                    <Columns name='sai prasad'/>
                    <Columns  name='Suresh'/>
                </tr>
                
            </tbody>
        </table>
    )
}
export default Table