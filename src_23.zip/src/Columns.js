import React from 'react'
import './App.css';

function Columns(props) {
  return (
      <td>{props.name}</td>
  )
}

export default Columns