import React, { Component } from 'react'

export class Sample extends Component {
constructor(props) {
  super(props)

  this.state = {
      first: 'sreenivas',
      last: 'gorantla'
  }
}  
  render() {
    return (
        <div>
            <h2> {this.state.first}</h2> <h2> {this.state.last}</h2>
        </div>
    )
  }
}

export default Sample

// React Snippets 
// ===================

// rce  : for create a class
// rconst : for create a constructor 
// rfce : functional component
// ES7 + ReactRedux/React-Native snippets 