
import React from 'react';
import './App.css';

function Emp(props) {
  return (
    <div className='emp'>
      
        <img src= {props.link}  /> 
          <p>
              <span> Emp ID</span> <span>{props.emp_id}</span>
          </p>
           <p>
              <span> Emp Name</span> <span>{props.emp_name}</span>
          </p>
           <p>
              <span> Emp Salary</span> <span>{props.emp_sal}</span>
          </p>
          <hr/>
      </div>
  );
}

export default Emp;
