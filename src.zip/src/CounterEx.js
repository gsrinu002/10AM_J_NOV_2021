import React from 'react';
import './App.css';

// class  component 
class CounterEx extends React.Component {

    constructor() {
        super()

        this.state = {
          mess:0
        }

    }
//  method
    updateCounter() {

        this.setState({
              mess:this.state.mess+1 
        })
        
    }
    
    render() {
        return (
            <div className='emp'>
                <h1> Counter value is ..  {this.state.mess}</h1>
              <button onClick={ () => this.updateCounter() }> Update Counter</button>
            </div>
        );
    };

}
export default CounterEx;
