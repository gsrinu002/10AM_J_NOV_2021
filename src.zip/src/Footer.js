
import './App.css';
function Footer() {
  return (
    <div className='footer'>
            <h4 style={{textAlign:'center'}}> copy rights from sunadh technogies @2022 </h4>  
    </div>
  );
}

export default Footer;
