import React from 'react';
import './App.css';

// class  component 
class StateEX extends React.Component {

    constructor() {
        super()

        this.state = {
          mess:"sreenivas"
        }

    }
//  method
    setMessage() {

        this.setState({
              mess:"Fullstack"
        })
        
    }
    
    render() {
        return (
            <div className='emp'>
                <h1>{this.state.mess}</h1>
                <button onClick={ () => this.setMessage() }> Click me for change name</button>
            </div>
        );
    };

}
export default StateEX;
