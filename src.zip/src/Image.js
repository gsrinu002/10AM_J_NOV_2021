
import './App.css';

// functional component 

function Image() {

  return (
    <div className='image'>
           <img src='https://onextrapixel.com/wp-content/uploads/2016/04/reactjs-thumb.jpg'/>
    </div>
  );
}

export default Image;


