
import './App.css';

function Header() {

 const sunadh = {
      color: "white",
      backgroundColor: "DodgerBlue",
      padding: "10px",
      fontFamily: "Arial"
    };
  
  return (
    <div className='header' id='header'>
            <h1 style={sunadh}> hello react welcome to sunadh </h1>  
    </div>
  );
}

export default Header;
