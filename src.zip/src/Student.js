
import React from 'react';
import './App.css';


function Student() {

  return (
      <div className='emp'>
          {/* Events  */}
          
          <h1 onClick={ () => alert('clicked')}> Click  Me </h1>
          <h1 onDoubleClick={ () => alert('double clicked')}> Double Click Me </h1>
          <h1 onMouseOver={() => console.log("mouse over done")}
              onMouseOut={ () => console.log("mouse out done") }
          
          > MouseOver and Mouseout on me  </h1>

          <input
              type='text'
              onFocus={()=> document.getElementsByTagName('input')[0].style.color='red'}
              onBlur={() => document.getElementsByTagName('input')[0].style.color='' }
              placeholder='enter ur name'
           /> 

      </div>
  );
}

export default Student;
