import React from 'react';
import './App.css';
import { Button } from 'reactstrap';

// class  component 
class Employee extends React.Component {

    constructor(props)
    {
        super(props)
    }

    render()
    {
        return (

            <div className='emp'>
                   <div>
                    <img src={this.props.emp_logo} /><br/>
                    <span> Emp ID</span><br/>
                    <span>{this.props.emp_id}</span><br/>
                    <span>
                        <Button color="danger">Like</Button>
                    </span><br/>
                   </div>
            </div>
        );
    };
}

export default Employee;
